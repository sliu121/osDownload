#include<linux/linkage.h>
#include<linux/export.h>
#include<linux/time.h>
#include<asm/uaccess.h>
#include<linux/printk.h>
#include<linux/slab.h>

asmlinkage int sys_my_xtime(struct timespec *current_time)
{
	if(!access_ok(VERIFY_WRITE,current_time,sizeof(struct timespec)))
		return -EFAULT;
	else
	{
		struct timespec k_time=current_kernel_time();
		copy_to_user(current_time,&k_time,sizeof(struct timespec));
		printk(KERN_ALERT"this is my_xtime.Current_time is %ld \n",current_time->tv_nsec);
		return 0;
	}
}

EXPORT_SYMBOL(sys_my_xtime);
