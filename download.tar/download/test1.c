#include<stdio.h>
#include<errno.h>
#include<unistd.h>
#include<linux/unistd.h>
#include<linux/time.h>
#define __NR_sys_my_xtime 326

int main()
{
	int ret;
	struct timespec now_time;
		
		
			ret=syscall(326,&now_time);
			printf("ret is %d, now_time is %ld\n",ret,now_time.tv_nsec);
			sleep(1);
		
	return 0;
}
